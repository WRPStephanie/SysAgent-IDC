use nvml::NvmlInfo;
use std::ffi::CString;
pub mod diag;
pub mod errors;
pub mod gpu;
pub mod gpu_process;
pub mod gpudiag;
pub mod gx;
pub mod infiniband;
pub mod kmsg;
pub mod nvml;
pub mod rocm_smi;

#[no_mangle]
pub fn gpuprocess_metrics_read(cb: unsafe extern "C" fn(i32, i32, *const std::ffi::c_char)) {
    let procs = nvml::nvml_gpu_processes();
    for (g, p, cmdline) in &procs {
        if let Ok(c_cmdline) = CString::new(cmdline.as_str()) {
            unsafe { cb(*g as i32, *p as i32, c_cmdline.as_ptr()) };
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    extern "C" fn slow_node_read(_a: i32, _b: i32, _c: *const std::ffi::c_char) {}

    #[test]
    fn test_gpuprocess_metrics_read() {
        gpuprocess_metrics_read(slow_node_read);
    }
}
