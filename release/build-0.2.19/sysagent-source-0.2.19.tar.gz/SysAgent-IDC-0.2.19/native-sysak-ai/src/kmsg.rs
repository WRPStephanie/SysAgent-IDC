use crossbeam_channel::Receiver;
use rmesg::{self, entry::Entry};
use std::{
    ffi::{CStr, CString},
    thread::JoinHandle,
};

pub struct KmsgCollector {
    _thread: JoinHandle<()>,
    rx: Receiver<Entry>,
}

#[no_mangle]
pub fn kmsg_iterator_create() -> *mut KmsgCollector {
    let (tx, rx) = crossbeam_channel::unbounded();
    let handle = match rmesg::logs_iter(rmesg::Backend::DevKMsg, false, false) {
        Ok(mut msg_iter) => std::thread::spawn(move || loop {
            match msg_iter.next() {
                Some(Ok(msg)) => {
                    tx.send(msg)
                        .expect("kmsg collector exited cause other side has closed channel");
                }
                Some(Err(_)) => break,
                None => break,
            };
        }),
        Err(_) => return std::ptr::null_mut(),
    };

    let coll = KmsgCollector {
        _thread: handle,
        rx,
    };

    Box::into_raw(Box::new(coll))
}

#[no_mangle]
pub fn kmsg_iterator_read(
    iter: *mut KmsgCollector,
    cb: unsafe extern "C" fn(
        *const libc::c_char,
        *const libc::c_char,
        *const libc::c_char,
        u64,
        u64,
    ),
) {
    let iter = match unsafe { iter.as_mut() } {
        Some(iter) => iter,
        None => return,
    };

    loop {
        match iter.rx.try_recv() {
            Ok(msg) => {
                let facility =
                    CString::new(msg.facility.map_or("None".to_string(), |x| x.to_string()))
                        .unwrap();
                let level =
                    CString::new(msg.level.map_or("None".to_string(), |x| x.to_string())).unwrap();
                let content = CString::new(msg.message).unwrap();
                let seq = msg.sequence_num.unwrap_or(0);
                let time = msg.timestamp_from_system_start.map_or(0, |x| x.as_secs());

                unsafe {
                    cb(
                        facility.as_ptr(),
                        level.as_ptr(),
                        content.as_ptr(),
                        seq as u64,
                        time,
                    )
                };
            }
            Err(_) => break,
        };
    }
}

#[no_mangle]
pub fn kmsg_iterator_destroy(iter: *mut KmsgCollector) {
    if !iter.is_null() {
        unsafe { std::ptr::drop_in_place(iter) }
    }
}

#[cfg(test)]
unsafe extern "C" fn callback(
    facility: *const libc::c_char,
    level: *const libc::c_char,
    content: *const libc::c_char,
    seq: u64,
    time: u64,
) {
    println!(
        "{:?} {:?} {:?} {} {}",
        CStr::from_ptr(facility),
        CStr::from_ptr(level),
        CStr::from_ptr(content),
        seq,
        time
    );
}

#[test]
fn test_kmsg() {
    let iter = kmsg_iterator_create();
    assert!(!iter.is_null());
    std::thread::sleep(std::time::Duration::from_millis(100));
    kmsg_iterator_read(iter, callback);
    kmsg_iterator_destroy(iter);
}
