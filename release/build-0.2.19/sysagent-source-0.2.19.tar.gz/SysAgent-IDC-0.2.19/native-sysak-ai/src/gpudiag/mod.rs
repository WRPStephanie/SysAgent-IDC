use crate::nvml::NvmlInfo;
use anyhow::Result;

pub mod card_drop;
pub mod dmesg;
pub mod pci;
pub mod proc;

/// 统一硬件健康检测结果项：(中文描述, 英文描述)
pub type CheckItem = (String, String);

/// PCI 检测的结论，用于决定如何上报
#[derive(Debug, PartialEq)]
pub enum PciCheckOutcome {
    /// 检测到支持的 GPU
    Ok,
    /// 检测到 GPU 类设备但厂商不在支持列表
    UnsupportedVendor(Vec<String>),
    /// 未检测到任何 GPU 类设备
    NoDevice,
}

/// 根据支持的 GPU 列表和 GPU 类设备列表，决定 PCI 检测结论
///
/// 规则：
/// - 有支持的 GPU → Ok（不上报）
/// - lspci 本身失败 → Ok（不能因为命令不可用而误报无设备）
/// - 有 GPU 类设备但厂商不支持 → UnsupportedVendor（info log，不上报错误）
/// - 什么都没有 → NoDevice（上报错误）
pub fn evaluate_pci_detection(
    supported: &[String],
    unsupported: &[String],
    pci_failed: bool,
) -> PciCheckOutcome {
    if !supported.is_empty() {
        return PciCheckOutcome::Ok;
    }
    if pci_failed {
        return PciCheckOutcome::Ok;
    }
    if !unsupported.is_empty() {
        return PciCheckOutcome::UnsupportedVendor(unsupported.to_vec());
    }
    PciCheckOutcome::NoDevice
}

/// 运行所有 gpudiag 检测，将结果合并到 NvmlInfo 的 errors 数组中。
/// 不修改 NvmlInfo 的字段结构，只通过 errors / errors_en 上报。
pub fn check_all(nvml: &mut NvmlInfo) -> Result<()> {
    let mut all_errors: Vec<CheckItem> = vec![];

    // 1. PCI 检测：发现 GPU 设备
    // 只调用一次 lspci，然后分别解析支持的 GPU 和所有 GPU 类设备
    let (supported, unsupported, pci_failed) = match pci::run_lspci() {
        Ok(output) => {
            let supported = pci::parse_pci_gpus(&output);
            let unsupported = pci::parse_gpu_like_pci_devices(&output);
            (supported, unsupported, false)
        }
        Err(e) => {
            log::debug!("pci detection failed: {}", e);
            (vec![], vec![], true)
        }
    };

    match evaluate_pci_detection(&supported, &unsupported, pci_failed) {
        PciCheckOutcome::UnsupportedVendor(devices) => {
            log::info!("PCI 检测到 GPU 类设备但无法识别厂商: {:?}", devices);
        }
        PciCheckOutcome::NoDevice => {
            all_errors.push((
                "PCI检测: 未通过lspci发现GPU设备".to_string(),
                "PCI check: No GPU devices found via lspci".to_string(),
            ));
        }
        PciCheckOutcome::Ok => {}
    }

    // 2. dmesg 检测（NVIDIA / PPU 显卡错误）
    if let Ok(dmesg_errs) = dmesg::check_dmesg_gpu(&nvml.gpus) {
        all_errors.extend(dmesg_errs);
    }

    // 3. Z/D 状态进程检测
    if let Ok(proc_errs) = proc::check_zombie_disk_on_gpu(&nvml.processes) {
        all_errors.extend(proc_errs);
    }

    // 4. 掉卡检测（lspci vs smi count）
    if let Ok(drop_errs) = card_drop::check_card_drop() {
        all_errors.extend(drop_errs);
    }

    // 统一上报到 NvmlInfo（不改变字段结构）
    for (zh, en) in all_errors {
        nvml.errors.push(zh);
        nvml.errors_en.push(en);
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_all_no_panic() {
        let mut nvml = NvmlInfo::default();
        // 不 panic 即可，具体错误取决于运行环境是否有 lspci/dmesg 等
        let result = check_all(&mut nvml);
        assert!(result.is_ok());
    }

    #[test]
    fn test_check_all_with_supported_gpu() {
        pci::set_test_lspci_output(Some(
            "0000:01:00.0 3D controller: NVIDIA Corporation GA102GL [A10]\n".to_string(),
        ));
        let mut nvml = NvmlInfo::default();
        let result = check_all(&mut nvml);
        assert!(result.is_ok());
        assert!(nvml.errors.is_empty(), "支持的 GPU 不应产生 PCI 错误");
    }

    #[test]
    fn test_check_all_with_unsupported_vendor() {
        pci::set_test_lspci_output(Some(
            "0000:01:00.0 VGA compatible controller: Intel Corporation Device 1234\n".to_string(),
        ));
        let mut nvml = NvmlInfo::default();
        let result = check_all(&mut nvml);
        assert!(result.is_ok());
        assert!(nvml.errors.is_empty(), "不支持厂商不应作为错误上报");
    }

    #[test]
    fn test_check_all_with_no_gpu_device() {
        pci::set_test_lspci_output(Some("Ethernet controller: Realtek Semiconductor Co., Ltd. Device 8168\n".to_string()));
        let mut nvml = NvmlInfo::default();
        let result = check_all(&mut nvml);
        assert!(result.is_ok());
        assert!(!nvml.errors.is_empty(), "无 GPU 设备时应上报错误");
    }

    #[test]
    fn test_check_all_with_lspci_failure() {
        pci::set_test_lspci_output(None);
        let mut nvml = NvmlInfo::default();
        let result = check_all(&mut nvml);
        assert!(result.is_ok());
        assert!(nvml.errors.is_empty(), "lspci 失败时不应误报无设备");
    }

    #[test]
    fn test_evaluate_pci_detection_with_supported_gpu() {
        let supported = vec!["NVIDIA GPU".to_string()];
        let unsupported = vec!["Intel GPU".to_string()];
        assert_eq!(
            evaluate_pci_detection(&supported, &unsupported, false),
            PciCheckOutcome::Ok
        );
    }

    #[test]
    fn test_evaluate_pci_detection_unsupported_vendor() {
        let supported: Vec<String> = vec![];
        let unsupported = vec!["Intel GPU".to_string(), "Huawei NPU".to_string()];
        assert_eq!(
            evaluate_pci_detection(&supported, &unsupported, false),
            PciCheckOutcome::UnsupportedVendor(unsupported.clone())
        );
    }

    #[test]
    fn test_evaluate_pci_detection_no_device() {
        let supported: Vec<String> = vec![];
        let unsupported: Vec<String> = vec![];
        assert_eq!(
            evaluate_pci_detection(&supported, &unsupported, false),
            PciCheckOutcome::NoDevice
        );
    }

    #[test]
    fn test_evaluate_pci_detection_lspci_failed() {
        let supported: Vec<String> = vec![];
        let unsupported: Vec<String> = vec![];
        assert_eq!(
            evaluate_pci_detection(&supported, &unsupported, true),
            PciCheckOutcome::Ok
        );
    }
}
