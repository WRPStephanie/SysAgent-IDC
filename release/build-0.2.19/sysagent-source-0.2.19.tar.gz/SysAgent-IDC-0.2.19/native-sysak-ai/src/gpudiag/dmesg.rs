use super::CheckItem;
use crate::gpu::Gpu;
use anyhow::Result;
use regex::Regex;
use std::process::Command;

/// 检测 dmesg 中的 GPU 相关错误模式
pub fn check_dmesg_gpu(gpus: &[Gpu]) -> Result<Vec<CheckItem>> {
    let output = Command::new("dmesg").arg("--time-format=notime").output();

    let output = match output {
        Ok(o) => o,
        Err(_) => return Ok(vec![]),
    };

    let stdout = String::from_utf8_lossy(&output.stdout);
    Ok(check_dmesg_gpu_with_text(gpus, &stdout))
}

/// 从给定的 dmesg 文本中检测 GPU 错误（纯逻辑，便于测试）
pub fn check_dmesg_gpu_with_text(gpus: &[Gpu], text: &str) -> Vec<CheckItem> {
    let mut errors = vec![];
    let mut seen = std::collections::HashSet::new();

    // 收集所有 NVRM fallen off the bus 的 GPU 标识，最后合并为一条事件
    let mut fallen_off_gpus: Vec<String> = vec![];
    let bdf_re = Regex::new(r"GPU\s+([0-9a-fA-F:]+(?:\.\d)?)").unwrap();

    for line in text.lines() {
        let lower = line.to_lowercase();

        // NVIDIA GPU 错误
        if lower.contains("nvrm") {
            // RmInitAdapter failed / rm_init_adapter failed 归为一类
            if lower.contains("rm_init_adapter failed")
                || lower.contains("rminitadapter failed")
            {
                let key = "nvrm_rm_init_adapter_failed";
                if !seen.contains(key) {
                    seen.insert(key.to_string());
                    errors.push((
                        format!("dmesg: NVIDIA GPU 适配器初始化失败 - {}", truncate(line, 120)),
                        format!(
                            "dmesg: NVIDIA GPU adapter initialization failed - {}",
                            truncate(line, 120)
                        ),
                    ));
                }
            }

            // NVRM 报告的 GPU fallen off the bus：提取 GPU 号并合并上报
            if lower.contains("fallen off the bus") || lower.contains("gpu lost") {
                let label = match extract_gpu_label(line, &bdf_re, gpus) {
                    Some(l) => l,
                    None => "UNKNOWN".to_string(),
                };
                if !fallen_off_gpus.contains(&label) {
                    fallen_off_gpus.push(label);
                }
            }
        }

        // PCIe AER 错误（通用，影响 GPU）
        if lower.contains("aer") && (lower.contains("uncorrect") || lower.contains("fatal")) {
            let key = "pcie_aer_fatal";
            if !seen.contains(key) {
                seen.insert(key.to_string());
                errors.push((
                    format!("dmesg: PCIe AER 不可纠正错误 - {}", truncate(line, 120)),
                    format!("dmesg: PCIe AER uncorrectable error - {}", truncate(line, 120)),
                ));
            }
        }

        // PPU 错误
        if lower.contains("ppu") && (lower.contains("error") || lower.contains("fault")) {
            let key = "ppu_error";
            if !seen.contains(key) {
                seen.insert(key.to_string());
                errors.push((
                    format!("dmesg: PPU GPU 错误 - {}", truncate(line, 120)),
                    format!("dmesg: PPU GPU error - {}", truncate(line, 120)),
                ));
            }
        }

        // 非 NVRM 来源的 GPU 从 PCIe 总线掉落
        if !lower.contains("nvrm")
            && (lower.contains("fallen off the bus") || lower.contains("gpu lost"))
        {
            let key = "gpu_lost";
            if !seen.contains(key) {
                seen.insert(key.to_string());
                errors.push((
                    "dmesg: GPU 已从 PCIe 总线掉落".to_string(),
                    "dmesg: GPU has fallen off the PCIe bus".to_string(),
                ));
            }
        }

        // NVLink 错误
        if lower.contains("nvlink") && lower.contains("error") {
            let key = "nvlink_error";
            if !seen.contains(key) {
                seen.insert(key.to_string());
                errors.push((
                    format!("dmesg: NVLink 错误 - {}", truncate(line, 120)),
                    format!("dmesg: NVLink error - {}", truncate(line, 120)),
                ));
            }
        }
    }

    // 合并所有 NVRM fallen off the bus 事件为一条
    if !fallen_off_gpus.is_empty() {
        let gpu_list = fallen_off_gpus.join(",");
        errors.push((
            format!("dmesg: NVIDIA GPU {} 从 PCIe 总线掉卡", gpu_list),
            format!("dmesg: NVIDIA GPU {} fell off the PCIe bus", gpu_list),
        ));
    }

    errors
}

/// 从 dmesg 行中提取 GPU 标识：优先映射为 GPU index，否则返回 PCI BDF
fn extract_gpu_label(line: &str, bdf_re: &Regex, gpus: &[Gpu]) -> Option<String> {
    let caps = bdf_re.captures(line)?;
    let bdf = caps[1].to_uppercase();

    // 尝试匹配 NvmlInfo.gpus 中的 bus_id，返回 GPU index
    for (i, gpu) in gpus.iter().enumerate() {
        let bus = gpu.bus_id.to_uppercase();
        if bus.contains(&bdf) || bdf.contains(&bus) {
            return Some(format!("GPU{}", i));
        }
    }

    // 无法映射到 index，直接返回 BDF
    Some(bdf)
}

fn truncate(s: &str, max_len: usize) -> &str {
    if s.len() <= max_len {
        s
    } else {
        &s[..max_len]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_dmesg_gpu_empty() {
        let result = check_dmesg_gpu(&[]);
        assert!(result.is_ok());
    }

    #[test]
    fn test_check_dmesg_gpu_with_text_clean() {
        let text = "[    0.000000] Linux version 5.10.0\n";
        let errors = check_dmesg_gpu_with_text(&[], text);
        assert!(errors.is_empty());
    }

    #[test]
    fn test_check_dmesg_gpu_with_text_rminit() {
        let text = "[  123.456] NVRM: GPU 0000:AC:00.0: RmInitAdapter failed!\n";
        let errors = check_dmesg_gpu_with_text(&[], text);
        assert_eq!(errors.len(), 1);
        assert!(errors[0].0.contains("适配器初始化失败"));
    }

    #[test]
    fn test_check_dmesg_gpu_with_text_fallen_off_bus_merged() {
        use crate::nvml::DeviceWrapper;

        let mut dev0 = DeviceWrapper::new();
        dev0.bus_id = "0000:AC:00.0".to_string();
        let mut dev1 = DeviceWrapper::new();
        dev1.bus_id = "0000:DD:00.0".to_string();
        let gpus = vec![Gpu::from(&dev0), Gpu::from(&dev1)];

        let text = "[  100.000] NVRM: GPU 0000:AC:00.0: GPU has fallen off the bus\n\
                     [  100.001] NVRM: GPU 0000:DD:00.0: GPU has fallen off the bus\n\
                     [  100.002] NVRM: GPU 0000:AC:00.0: GPU has fallen off the bus\n";
        let errors = check_dmesg_gpu_with_text(&gpus, text);

        // 应该合并为一条事件，而不是三条
        assert_eq!(errors.len(), 1);
        assert!(errors[0].0.contains("GPU0,GPU1"));
        assert!(errors[0].0.contains("从 PCIe 总线掉卡"));
    }

    #[test]
    fn test_check_dmesg_gpu_with_text_pcie_aer() {
        let text = "[  200.000] pcieport 0000:00:01.0: AER: Uncorrected (Non-Fatal) error received\n";
        let errors = check_dmesg_gpu_with_text(&[], text);
        assert_eq!(errors.len(), 1);
        assert!(errors[0].0.contains("PCIe AER"));
    }

    #[test]
    fn test_extract_gpu_label() {
        use crate::nvml::DeviceWrapper;

        let re = Regex::new(r"GPU\s+([0-9a-fA-F:]+(?:\.\d)?)").unwrap();

        // 无 GPU 列表时返回 BDF
        assert_eq!(
            extract_gpu_label("NVRM: GPU 0000:AC:00.0: GPU has fallen off the bus", &re, &[]),
            Some("0000:AC:00.0".to_string())
        );

        // 能映射到 GPU index
        let mut dev = DeviceWrapper::new();
        dev.bus_id = "0000:AC:00.0".to_string();
        let gpu = Gpu::from(&dev);
        assert_eq!(
            extract_gpu_label("NVRM: GPU 0000:AC:00.0: GPU has fallen off the bus", &re, &[gpu]),
            Some("GPU0".to_string())
        );
    }

    #[test]
    fn test_truncate() {
        assert_eq!(truncate("hello", 10), "hello");
        assert_eq!(truncate("hello world", 5), "hello");
    }
}
