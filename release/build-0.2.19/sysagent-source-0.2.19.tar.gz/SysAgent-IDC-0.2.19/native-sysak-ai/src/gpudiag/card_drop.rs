use super::CheckItem;
use anyhow::Result;
use std::process::Command;

/// 检测掉卡：通过 lspci 检测到的 GPU 数量 vs nvidia-smi 检测到的数量
pub fn check_card_drop() -> Result<Vec<CheckItem>> {
    let pci_text = run_command_output("lspci", &[]);
    let smi_text = run_command_output("nvidia-smi", &["-L"]);
    Ok(check_card_drop_with_text(&pci_text, &smi_text))
}

/// 根据 lspci 和 nvidia-smi 的输出文本判断掉卡（纯逻辑，便于测试）
pub fn check_card_drop_with_text(pci_text: &str, smi_text: &str) -> Vec<CheckItem> {
    let pci_count = count_pci_nvidia_gpus(pci_text);
    let smi_count = count_smi_gpus(smi_text);

    // 如果两侧都无法获取，跳过检测
    if pci_count == 0 && smi_count == 0 {
        return vec![];
    }

    // pci_count > 0 且 smi_count 更少，说明有 GPU 掉卡
    if pci_count > 0 && smi_count < pci_count {
        return vec![(
            format!(
                "掉卡检测: lspci 发现 {} 块 NVIDIA GPU，但 nvidia-smi 只显示 {} 块，疑似掉卡",
                pci_count, smi_count
            ),
            format!(
                "Card drop: lspci found {} NVIDIA GPU(s), but nvidia-smi only shows {}, possible card drop",
                pci_count, smi_count
            ),
        )];
    }

    vec![]
}

/// 通过 lspci 统计 NVIDIA GPU 数量
fn count_pci_nvidia_gpus(output: &str) -> usize {
    output
        .lines()
        .filter(|l| {
            let low = l.to_lowercase();
            low.contains("nvidia")
                && (low.contains("3d controller")
                    || low.contains("vga compatible")
                    || low.contains("display controller"))
        })
        .count()
}

/// 通过 nvidia-smi 统计 GPU 数量
fn count_smi_gpus(output: &str) -> usize {
    output
        .lines()
        .filter(|l| l.starts_with("GPU "))
        .count()
}

/// 运行外部命令并返回 stdout 字符串；失败返回空字符串
fn run_command_output(cmd: &str, args: &[&str]) -> String {
    match Command::new(cmd).args(args).output() {
        Ok(o) if o.status.success() => String::from_utf8_lossy(&o.stdout).to_string(),
        _ => String::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_card_drop() {
        // 只验证不 panic
        let result = check_card_drop();
        assert!(result.is_ok());
    }

    #[test]
    fn test_check_card_drop_with_text_detected() {
        let pci = "0000:01:00.0 3D controller: NVIDIA Corporation A10\n\
                   0000:02:00.0 3D controller: NVIDIA Corporation A10\n";
        let smi = "GPU 0: NVIDIA A10 (UUID: GPU-xxx)\n";
        let errors = check_card_drop_with_text(pci, smi);
        assert_eq!(errors.len(), 1);
        assert!(errors[0].0.contains("2"));
        assert!(errors[0].0.contains("1"));
    }

    #[test]
    fn test_check_card_drop_with_text_no_drop() {
        let pci = "0000:01:00.0 3D controller: NVIDIA Corporation A10\n";
        let smi = "GPU 0: NVIDIA A10 (UUID: GPU-xxx)\n";
        let errors = check_card_drop_with_text(pci, smi);
        assert!(errors.is_empty());
    }

    #[test]
    fn test_check_card_drop_with_text_both_empty() {
        let errors = check_card_drop_with_text("", "");
        assert!(errors.is_empty());
    }
}
