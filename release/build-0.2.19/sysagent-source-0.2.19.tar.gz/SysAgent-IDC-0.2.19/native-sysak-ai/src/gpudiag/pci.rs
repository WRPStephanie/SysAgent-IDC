use anyhow::Result;

#[cfg(test)]
use std::cell::RefCell;

/// 支持的 GPU 厂商关键字（英伟达、AMD、PPU/天数）
const SUPPORTED_GPU_VENDORS: &[&str] = &["nvidia", "amd", "ppu"];

/// GPU 类 PCI 设备 class 关键字（不区分厂商，用于区分"无设备"和"厂商不支持"）
/// 注意：non-vga unclassified device 通常是华为NPU，不在支持厂商列表中，
/// 但需要被识别为 GPU 类设备以便正确分类。
const GPU_PCI_CLASSES: &[&str] = &[
    "3d controller",
    "display controller",
    "vga compatible controller",
    "processing accelerators",
    "non-vga unclassified device",
];

#[cfg(test)]
thread_local! {
    /// 测试用于注入 lspci 输出：
    /// - `None` 表示使用真实 lspci 命令
    /// - `Some(None)` 表示模拟 lspci 执行失败
    /// - `Some(Some(output))` 表示模拟 lspci 返回指定输出
    static TEST_LSPCI_OUTPUT: RefCell<Option<Option<String>>> = RefCell::new(None);
}

#[cfg(test)]
/// 设置测试用 lspci 输出，供 `run_lspci` 及其包装函数复用。
pub fn set_test_lspci_output(output: Option<String>) {
    TEST_LSPCI_OUTPUT.with(|o| *o.borrow_mut() = Some(output));
}

/// 运行 lspci 并返回原始输出
pub fn run_lspci() -> Result<String> {
    #[cfg(test)]
    {
        let test_output = TEST_LSPCI_OUTPUT.with(|o| o.borrow_mut().take());
        if let Some(output) = test_output {
            return match output {
                Some(s) => Ok(s),
                None => Err(anyhow::anyhow!("mock lspci failure")),
            };
        }
    }
    let output = std::process::Command::new("lspci")
        .output()
        .map_err(|e| anyhow::anyhow!("lspci failed: {}", e))?;
    Ok(String::from_utf8_lossy(&output.stdout).to_string())
}

/// 通过 lspci 发现支持的 GPU 设备（AMD / PPU / 英伟达）
pub fn detect_pci_gpus() -> Result<Vec<String>> {
    Ok(parse_pci_gpus(&run_lspci()?))
}

/// 通过 lspci 发现所有 GPU 类 PCI 设备（不限厂商，用于区分"无设备"和"厂商不支持"）
pub fn detect_gpu_like_pci_devices() -> Result<Vec<String>> {
    Ok(parse_gpu_like_pci_devices(&run_lspci()?))
}

/// 从 lspci 输出中解析支持的 GPU 设备行
pub fn parse_pci_gpus(output: &str) -> Vec<String> {
    parse_pci_devices(output, SUPPORTED_GPU_VENDORS)
}

/// 从 lspci 输出中解析所有 GPU 类设备行（不限厂商）
pub fn parse_gpu_like_pci_devices(output: &str) -> Vec<String> {
    parse_pci_devices(output, &[])
}

fn parse_pci_devices(output: &str, vendors: &[&str]) -> Vec<String> {
    let mut devices = vec![];

    for line in output.lines() {
        let lower = line.to_lowercase();
        if is_gpu_pci_class(&lower) {
            if vendors.is_empty() || vendors.iter().any(|v| lower.contains(v)) {
                devices.push(line.to_string());
            }
        }
    }

    devices
}

fn is_gpu_pci_class(lower: &str) -> bool {
    GPU_PCI_CLASSES.iter().any(|c| lower.contains(c))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_pci_gpus() {
        // lspci 可能不存在或无 GPU，只验证不 panic
        let _ = detect_pci_gpus();
    }

    #[test]
    fn test_run_lspci_success_with_mock() {
        set_test_lspci_output(Some("0000:01:00.0 3D controller: NVIDIA Corporation GA102GL [A10]\n".to_string()));
        let output = run_lspci().unwrap();
        assert!(output.contains("NVIDIA"));
    }

    #[test]
    fn test_run_lspci_failure_with_mock() {
        set_test_lspci_output(None);
        assert!(run_lspci().is_err());
    }

    #[test]
    fn test_detect_pci_gpus_with_mock() {
        set_test_lspci_output(Some("0000:01:00.0 3D controller: NVIDIA Corporation GA102GL [A10]\n\
                                     0000:02:00.0 VGA compatible controller: Intel Corporation Device 1234\n".to_string()));
        let gpus = detect_pci_gpus().unwrap();
        assert_eq!(gpus.len(), 1);
        assert!(gpus[0].contains("NVIDIA"));
    }

    #[test]
    fn test_detect_gpu_like_pci_devices_with_mock() {
        set_test_lspci_output(Some("0000:01:00.0 3D controller: NVIDIA Corporation GA102GL [A10]\n\
                                     0000:02:00.0 VGA compatible controller: Intel Corporation Device 1234\n".to_string()));
        let devices = detect_gpu_like_pci_devices().unwrap();
        assert_eq!(devices.len(), 2);
    }

    #[test]
    fn test_parse_pci_gpus_nvidia() {
        let output = "0000:01:00.0 3D controller: NVIDIA Corporation GA102GL [A10] (rev a1)\n\
                      0000:02:00.0 VGA compatible controller: Intel Corporation Device 1234\n\
                      0000:03:00.0 Ethernet controller: Realtek Semiconductor Co., Ltd. Device 8168\n";
        let gpus = parse_pci_gpus(output);
        assert_eq!(gpus.len(), 1);
        assert!(gpus[0].contains("NVIDIA"));
    }

    #[test]
    fn test_parse_pci_gpus_amd() {
        let output = "0000:0a:00.0 Processing accelerators: Advanced Micro Devices, Inc. [AMD/ATI] Aqua Vanjaram [Instinct MI308X]\n";
        let gpus = parse_pci_gpus(output);
        assert_eq!(gpus.len(), 1);
        assert!(gpus[0].to_lowercase().contains("amd"));
    }

    #[test]
    fn test_parse_pci_gpus_unsupported_vendor_as_info_not_error() {
        // Intel / 华为NPU 等不在支持列表的厂商，不应被视为支持的 GPU
        let output = "0000:01:00.0 VGA compatible controller: Intel Corporation Device 1234\n\
                      0000:02:00.0 Non-VGA unclassified device: Huawei Technologies Co., Ltd. Device abcd\n";
        let gpus = parse_pci_gpus(output);
        assert!(gpus.is_empty(), "Intel / Huawei NPU should NOT be treated as supported GPU");

        // 但应该能被识别为 GPU 类设备
        let devices = parse_gpu_like_pci_devices(output);
        assert_eq!(devices.len(), 2, "Intel / Huawei should still be GPU-like devices");
    }

    #[test]
    fn test_parse_pci_gpus_empty() {
        assert!(parse_pci_gpus("").is_empty());
        assert!(parse_pci_gpus("Ethernet controller: Realtek").is_empty());
    }

    #[test]
    fn test_parse_gpu_like_pci_devices_empty() {
        assert!(parse_gpu_like_pci_devices("").is_empty());
        assert!(parse_gpu_like_pci_devices("Ethernet controller: Realtek").is_empty());
    }
}
