use super::CheckItem;
use crate::gpu_process::GpuProcess;
use anyhow::Result;
use std::collections::HashMap;
use std::fs;

/// 检测 GPU 相关进程中是否有 Z（僵尸）或 D（不可中断等待）状态
pub fn check_zombie_disk_on_gpu(processes: &HashMap<u32, GpuProcess>) -> Result<Vec<CheckItem>> {
    let mut errors = vec![];

    for (&pid, proc) in processes {
        let state = read_proc_state(pid);
        match state.as_deref() {
            Some("Z") => {
                errors.push((
                    format!("进程 {} ({}) 处于僵尸状态(Z)", pid, proc.cmd),
                    format!("Process {} ({}) is in zombie state (Z)", pid, proc.cmd),
                ));
            }
            Some("D") => {
                errors.push((
                    format!(
                        "进程 {} ({}) 处于不可中断睡眠状态(D)，可能 GPU 驱动挂起",
                        pid, proc.cmd
                    ),
                    format!(
                        "Process {} ({}) is in uninterruptible sleep (D), possible GPU driver hang",
                        pid, proc.cmd
                    ),
                ));
            }
            _ => {}
        }
    }

    Ok(errors)
}

/// 读取 /proc/<pid>/status 中的 State 字段
fn read_proc_state(pid: u32) -> Option<String> {
    let path = format!("/proc/{}/status", pid);
    let content = fs::read_to_string(&path).ok()?;
    parse_proc_state(&content)
}

/// 从 /proc/<pid>/status 内容中解析 State 字段（纯逻辑，便于测试）
fn parse_proc_state(content: &str) -> Option<String> {
    for line in content.lines() {
        if line.starts_with("State:") {
            // "State:\tZ (zombie)"  → "Z"
            let parts: Vec<&str> = line.splitn(2, ':').collect();
            if parts.len() == 2 {
                let state = parts[1].trim();
                return state.chars().next().map(|c| c.to_string());
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_processes() {
        let map = HashMap::new();
        let result = check_zombie_disk_on_gpu(&map);
        assert!(result.is_ok());
        assert!(result.unwrap().is_empty());
    }

    #[test]
    fn test_read_proc_state_self() {
        // 读取当前进程状态，应该是 "S" 或 "R"
        let pid = std::process::id();
        let state = read_proc_state(pid);
        assert!(state.is_some());
        let s = state.unwrap();
        assert!(s == "S" || s == "R");
    }

    #[test]
    fn test_parse_proc_state_zombie() {
        let content = "Name:\ttest\nState:\tZ (zombie)\nPid:\t1234\n";
        assert_eq!(parse_proc_state(content), Some("Z".to_string()));
    }

    #[test]
    fn test_parse_proc_state_disk_sleep() {
        let content = "Name:\ttest\nState:\tD (disk sleep)\nPid:\t1234\n";
        assert_eq!(parse_proc_state(content), Some("D".to_string()));
    }

    #[test]
    fn test_parse_proc_state_missing() {
        assert_eq!(parse_proc_state("Name:\ttest\n"), None);
    }
}
