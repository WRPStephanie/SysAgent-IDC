use crate::errors::Errors;
use crate::gpu;
use crate::gpu::Gpu;
use crate::gpu_process::GpuProcess;
use crate::gpu_process::GpuProcessGpuInfo;
use crate::rocm_smi;
use crate::rocm_smi::has_rocm_smi;
use anyhow::Result;
use nvml_wrapper::enum_wrappers::device::PerformanceState;
use nvml_wrapper::enums::device::UsedGpuMemory;
use nvml_wrapper::error::nvml_sym;
use nvml_wrapper::struct_wrappers::device::MemoryInfo;
use nvml_wrapper::struct_wrappers::device::ProcessUtilizationSample;
use nvml_wrapper::Nvml;
use serde::Serialize;
use std::collections::hash_map::Entry;
use std::collections::HashMap;
use std::env;
use std::time::SystemTime;

#[derive(Debug)]
pub struct DeviceWrapper {
    pub fan: u32,
    pub temp: u32,
    pub perf: PerformanceState,
    pub power: u32,
    pub util: u32,
    pub mem: MemoryInfo,
    pub bus_id: String,
    pub procs: Vec<ProcessUtilizationSample>,
}

impl DeviceWrapper {
    pub fn new() -> Self {
        DeviceWrapper {
            fan: 0,
            temp: 0,
            perf: PerformanceState::Zero,
            power: 0,
            util: 0,
            mem: MemoryInfo {
                total: 0,
                free: 0,
                used: 0,
            },
            bus_id: "".to_string(),
            procs: vec![],
        }
    }
}

fn get_power_watts(power: u32) -> u32 {
    let res = ((power as f64) / 1000.0).round() as u32;
    res
}

// fn try_append_proc(total_mem: u64, procs: &mut Vec<ProcessUtilizationSample>, new_procs: &Vec<ProcessInfo>) {
//     for new_proc in new_procs {
//         let mut has_proc = false;
//         let pid = new_proc.pid;
//         for proc in  procs.iter(){
//             if proc.pid == pid {
//                 has_proc = true;
//                 break;
//             }
//         }
//         if has_proc {
//             continue;
//         }

//         let mem = match new_proc.used_gpu_memory {
//             UsedGpuMemory::Used(mem) => mem,
//             UsedGpuMemory::Unavailable => 0,
//         };
//         procs.push(ProcessUtilizationSample {
//             pid,
//             timestamp: 0,
//             mem_util: (mem/total_mem) as u32,
//             sm_util: 0,
//             enc_util: 0,
//             dec_util: 0,
//         })
//     }
// }

pub struct NvmlWrapper {
    pub devices: Vec<DeviceWrapper>,
}

impl NvmlWrapper {
    pub fn new() -> Result<Self> {
        let mut devices = vec![];

        if has_rocm_smi() {
            devices = rocm_smi::build_rocm_smi()?;
        } else if let Ok(nvml) = Nvml::init() {
            let device_count = nvml.device_count()?;
            log::debug!("device count: {device_count}");
            for i in 0..device_count {
                let device = nvml.device_by_index(i)?;
                log::debug!("found device: {:?}", device);
                let time_ms = SystemTime::now()
                    .duration_since(SystemTime::UNIX_EPOCH)?
                    .as_micros() as u64;
                let procs = if let Ok(procs) = device.process_utilization_stats(time_ms - 1000_000)
                {
                    procs
                } else {
                    vec![]
                };

                // let total_mem = device.memory_info()?.total;

                // match device.running_compute_processes() {
                //     Ok(compute_procs) => {
                //         try_append_proc(total_mem, &mut procs, &compute_procs);
                //     }
                //     Err(e) => {
                //         log::debug!("failed to read compute processes for gpu:{i}, error: {}", e);
                //     }
                // }

                // match device.running_graphics_processes() {
                //     Ok(graphic_procs) => {
                //         try_append_proc(total_mem, &mut procs, &graphic_procs);
                //     },
                //     Err(e) => {
                //         log::debug!("failed to read graphic processes for gpu:{i}, error: {}", e);
                //     }
                // }

                let mut fan = 0;
                let fan_count = device.num_fans()?;
                for i in 0..fan_count {
                    fan += device.fan_speed(i)?;
                }
                if fan_count != 0 {
                    fan /= fan_count;
                }

                let bus_id = match device.pci_info() {
                    Ok(p) => p.bus_id.clone(),
                    Err(_) => "".to_owned(),
                };

                log::debug!("bus_id: {bus_id}");
                let perf = match device.performance_state() {
                    Ok(p) => p,
                    Err(_) => PerformanceState::Unknown,
                };
                let dev = DeviceWrapper {
                    fan,
                    temp: device
                        .temperature(nvml_wrapper::enum_wrappers::device::TemperatureSensor::Gpu)?,
                    perf,
                    power: get_power_watts(device.power_usage()?),
                    util: device.utilization_rates()?.gpu,
                    mem: device.memory_info()?,
                    bus_id,
                    procs,
                };

                devices.push(dev);
            }
        }
        Ok(NvmlWrapper { devices })
    }
}

#[derive(Clone, Debug, Serialize, Default)]
pub struct NvmlInfo {
    pub gpus: Vec<Gpu>,
    pub processes: HashMap<u32, GpuProcess>,
    pub summary: String,
    pub summary_en: String,
    pub errors: Vec<String>,
    pub errors_en: Vec<String>,
    pub sysom_code: i32,
    pub sysom_err_msg: String,
    pub sysom_err_msg_en: String,
}

impl TryFrom<NvmlWrapper> for NvmlInfo {
    type Error = anyhow::Error;
    fn try_from(nvml: NvmlWrapper) -> Result<Self, Self::Error> {
        let mut gpus = vec![];
        let mut processes = HashMap::<u32, GpuProcess>::new();

        for (i, device) in nvml.devices.iter().enumerate() {
            gpus.push(Gpu::from(device));
            for proc in &device.procs {
                log::debug!("gpu process: {:?}", proc);

                let entry = processes.entry(proc.pid);
                match entry {
                    Entry::Occupied(_) => {}
                    Entry::Vacant(v) => {
                        let proc = GpuProcess::new(proc.pid)?;
                        v.insert(proc);
                    }
                };

                let tmp = processes
                    .entry(proc.pid)
                    .or_insert(GpuProcess::new(proc.pid).unwrap());
                tmp.gpus.push(GpuProcessGpuInfo {
                    id: i as u32,
                    mem_util: proc.mem_util,
                    sm_util: proc.sm_util,
                });
            }
        }
        Ok(NvmlInfo {
            gpus,
            processes,
            summary: "暂未发现问题".to_string(),
            summary_en: "No issues found".to_string(),
            errors: vec![],
            errors_en: vec![],
            sysom_code: 0,
            sysom_err_msg: "".to_string(),
            sysom_err_msg_en: "".to_string(),
        })
    }
}

impl NvmlInfo {
    pub fn new() -> Result<Self> {
        append_ld_library_path("/usr/lib/x86_64-linux-gnu/");
        let nvml = NvmlWrapper::new()?;
        Self::try_from(nvml)
    }

    pub fn add_gpu_errors(&mut self, bus_id: &String, errors: &Vec<Errors>) {
        if self.gpus.is_empty() {
            for err in errors {
                self.errors.push(err.to_string());
                self.errors_en.push(err.to_string_en());
            }
            return;
        }
        let bus_id = bus_id.to_uppercase();
        for gpu in self.gpus.iter_mut() {
            if gpu.bus_id.contains(&bus_id) {
                gpu.normal = false;
                for err in errors {
                    self.errors.push(err.to_string());
                    self.errors_en.push(err.to_string_en());
                }
                gpu.erros.extend_from_slice(&errors);
            }
        }
    }

    pub fn add_proc_error(&mut self, time: String, pid: u32, error: Errors) {
        self.errors.push(format!(
            "{time}: 进程{} hang住了,具体是:{}",
            pid,
            error.info.clone()
        ));
        self.errors_en.push(format!(
            "{time}: Process {} hang, details: {}",
            pid,
            error.info_en.clone()
        ));
        self.processes.entry(pid).and_modify(|x| {
            x.normal = false;
            x.erros.push(error)
        });
    }

    pub fn set_nccl_hang(&mut self, pid: u32, time: String, error: Errors) {
        self.errors.push(format!("{}: NCCL hang", time));
        self.errors_en.push(format!("{}: NCCL hang", time));
        self.processes.entry(pid).and_modify(|x| {
            x.normal = false;
            x.erros.push(error)
        });
    }

    pub fn set_driver_hang(&mut self) {
        self.errors.push("驱动程序hang了".to_owned());
        self.errors_en.push("Driver hang detected".to_owned());
    }

    pub fn build_summary(&mut self) {
        if self.errors.is_empty() {
            return;
        }

        let mut strings = vec![];
        strings.push(format!("共发现{}个问题:", self.errors.len()));
        strings.extend(
            self.errors
                .iter()
                .enumerate()
                .map(|(id, s)| format!("[{}]: {}", id + 1, s))
                .collect::<Vec<String>>(),
        );
        self.summary = strings.join("\n");

        let mut strings_en = vec![];
        strings_en.push(format!("Found {} issue(s):", self.errors_en.len()));
        strings_en.extend(
            self.errors_en
                .iter()
                .enumerate()
                .map(|(id, s)| format!("[{}]: {}", id + 1, s))
                .collect::<Vec<String>>(),
        );
        self.summary_en = strings_en.join("\n");
    }
}

pub fn nvml_gpu_processes() -> Vec<(u32, u32, String)> {
    let mut res = vec![];
    if let Ok(nvml) = Nvml::init() {
        let device_count = nvml.device_count().unwrap_or(0);
        for i in 0..device_count {
            if let Ok(device) = nvml.device_by_index(i) {
                if let Ok(procs) = device.running_compute_processes() {
                    for proc in procs {
                        let cmdline = read_proc_cmdline(proc.pid);
                        res.push((i, proc.pid, cmdline));
                    }
                }

                if let Ok(procs) = device.running_graphics_processes() {
                    for proc in procs {
                        let cmdline = read_proc_cmdline(proc.pid);
                        res.push((i, proc.pid, cmdline));
                    }
                }
            }
        }
    }
    res
}

fn read_proc_cmdline(pid: u32) -> String {
    let path = format!("/proc/{}/cmdline", pid);
    let mut cmdline = std::fs::read_to_string(&path).unwrap_or_default();
    cmdline = cmdline.replace('\0', " ");
    cmdline.truncate(128);
    if cmdline.is_empty() {
        "-".to_string()
    } else {
        cmdline
    }
}

pub fn append_ld_library_path(path: &str) {
    if path.is_empty() {
        return;
    }

    let key = "LD_LIBRARY_PATH";
    match env::var(key) {
        Ok(old) if !old.is_empty() => {
            // 已存在并且不为空，避免重复追加
            let parts: Vec<&str> = old.split(':').collect();
            if parts.contains(&path) {
                return;
            }
            let new_val = format!("{old}:{path}");
            let _ = env::set_var(key, new_val);
        }
        _ => {
            // 原来没有或为空，直接设置为该路径
            let _ = env::set_var(key, path);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{collections::HashMap, default};

    #[test]
    fn test_empty() {
        let _ = NvmlInfo::new();
    }

    #[test]
    fn test_one_device() {
        let mut nvml = NvmlWrapper::new().unwrap();
        nvml.devices.push(DeviceWrapper::new());
        let _ = NvmlInfo::try_from(nvml).unwrap();
    }

    #[test]
    fn test_two_devices() {
        let mut nvml = NvmlWrapper::new().unwrap();
        nvml.devices.push(DeviceWrapper::new());
        nvml.devices.push(DeviceWrapper::new());
        let _ = NvmlInfo::try_from(nvml).unwrap();
    }

    #[test]
    fn test_power_watts() {
        let res = get_power_watts(32655);
        assert_eq!(res, 33);
        assert_eq!(get_power_watts(32355), 32);
        nvml_gpu_processes();
    }

    #[test]
    fn test_append_ld_library_path() {
        let key = "LD_LIBRARY_PATH";

        // 先备份原有值，测试结束后恢复，避免影响其他测试
        let original = env::var(key).ok();

        // 1. 原来不存在或为空时，设置为新路径
        env::remove_var(key);
        append_ld_library_path("/tmp/lib1");
        let v = env::var(key).unwrap();
        assert_eq!(v, "/tmp/lib1");

        // 2. 再次追加不同路径，会在末尾加上 :path
        append_ld_library_path("/tmp/lib2");
        let v = env::var(key).unwrap();
        assert_eq!(v, "/tmp/lib1:/tmp/lib2");

        // 3. 追加已存在路径时，不应重复
        append_ld_library_path("/tmp/lib2");
        let v = env::var(key).unwrap();
        assert_eq!(v, "/tmp/lib1:/tmp/lib2");

        // 恢复原值
        match original {
            Some(val) => env::set_var(key, val),
            None => env::remove_var(key),
        }
    }
}
