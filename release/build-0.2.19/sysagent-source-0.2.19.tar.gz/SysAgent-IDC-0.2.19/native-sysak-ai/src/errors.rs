use serde::Deserialize;
use serde::Serialize;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Errors {
    pub time: String,
    pub info: String,
    pub sugg: String,
    pub info_en: String,
    pub sugg_en: String,
}

impl Errors {
    pub fn new(time: String, info: String, sugg: String, info_en: String, sugg_en: String) -> Self {
        Errors { time, info, sugg, info_en, sugg_en }
    }

    pub fn to_string(&self) -> String {
        format!("{} {}", self.time, self.info)
    }

    pub fn to_string_en(&self) -> String {
        format!("{} {}", self.time, self.info_en)
    }
}
