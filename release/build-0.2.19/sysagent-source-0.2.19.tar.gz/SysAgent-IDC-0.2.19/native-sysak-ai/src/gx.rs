use std::collections::HashMap;

use anyhow::Result;
use json::JsonValue;

use crate::errors::Errors;

#[derive(Debug, Default)]
pub struct GxHang {
    pub problems: Vec<String>,
    pub verboses: Vec<String>,
}

impl GxHang {
    pub fn new(json: &JsonValue) -> Self {
        let mut problems = Vec::new();
        let mut verboses = Vec::new();
        if json.has_key("problem") {
            if let JsonValue::Array(elems) = &json["problem"] {
                for elem in elems {
                    if let Some(x) = elem["name"].as_str() {
                        problems.push(x.to_string());
                    }
                    if let Some(x) = elem["verbose"].as_str() {
                        verboses.push(x.to_string());
                    }
                }
            }
        }

        GxHang { problems, verboses }
    }
}

#[derive(Debug, Default)]
pub struct GxRas {
    pub errors: HashMap<String, Vec<Errors>>,
}

impl GxRas {
    pub fn new(json: &JsonValue) -> Self {
        let mut res = HashMap::new();
        if json.has_key("problem") {
            if let JsonValue::Array(elems) = &json["problem"] {
                for elem in elems {
                    if let Some("GPU XID") = elem["name"].as_str() {
                        if let JsonValue::Array(verboses) = &elem["verbose"] {
                            for verbose in verboses {
                                let bus_id = verbose["bus_id"].to_string();
                                let mut res_errors = vec![];
                                if let JsonValue::Array(errors) = &verbose["errors"] {
                                    for error in errors {
                                        let time = error["time"].to_string();
                                        let info = format!(
                                            "XID编号是：{}，错误信息：{}",
                                            error["xid"].to_string(),
                                            error["message"].to_string()
                                        );
                                        let info_en = format!(
                                            "XID number: {}, error: {}",
                                            error["xid"].to_string(),
                                            error["message"].to_string()
                                        );
                                        let error = Errors::new(
                                            time, info, "N/A".to_owned(),
                                            info_en, "N/A".to_owned(),
                                        );
                                        res_errors.push(error);
                                    }
                                }

                                res.insert(bus_id, res_errors);
                            }
                        }
                    }
                }
            }
        }

        GxRas { errors: res }
    }
}

#[derive(Debug, Default)]
pub struct GxNccl {
    pub problems: Vec<String>,
    pub verboses: Vec<String>,
}

impl GxNccl {
    pub fn new(json: &JsonValue) -> Self {
        let mut problems = Vec::new();
        let mut verboses = Vec::new();
        if json.has_key("problem") {
            if let JsonValue::Array(elems) = &json["problem"] {
                for elem in elems {
                    if let Some(x) = elem["name"].as_str() {
                        problems.push(x.to_string());
                    }

                    if let Some(x) = elem["verbose"].as_str() {
                        verboses.push(x.to_string());
                    }
                }
            }
        }

        GxNccl { problems, verboses }
    }
}
#[derive(Debug)]
pub struct GxResult {
    pub hang: GxHang,
    pub ras: GxRas,
    pub nccl: GxNccl,
    pub driver_hang: bool,
}

impl GxResult {
    pub fn new(json: &JsonValue) -> Self {
        let mut hang = GxHang::default();
        let mut ras = GxRas::default();
        let mut nccl = GxNccl::default();
        let mut driver_hang = false;
        if let JsonValue::Array(elems) = &json["diag"] {
            for elem in elems {
                match elem["name"].as_str() {
                    Some("HANG DIAG") => hang = GxHang::new(&elem),
                    Some("RAS DIAG") => ras = GxRas::new(&elem),
                    Some("NCCL DIAG") => nccl = GxNccl::new(&elem),
                    Some("DRIVER DIAG") => {
                        if elem.has_key("problem") {
                            driver_hang = true;
                        }
                    }
                    _ => {}
                }
            }
        }

        GxResult {
            hang,
            ras,
            nccl,
            driver_hang,
        }
    }
}

pub struct Gx {
    path: String,
}

impl Gx {
    pub fn new(path: String) -> Gx {
        Gx { path }
    }

    pub fn run(&self, pid: u32, t_s: u64) -> Result<GxResult> {
        log::debug!("gx run pid: {}", pid);
        let output = std::process::Command::new(self.path.as_str())
            .arg("diag")
            .arg("-p")
            .arg(pid.to_string())
            .arg("-v")
            .arg("-f")
            .arg("json")
            .arg(t_s.to_string())
            .arg("2")
            .output()?;

        let out = String::from_utf8(output.stdout)?;
        let json = json::parse(&out)?;
        Ok(GxResult::new(&json))
    }

    pub fn detect_driver_hang(&self, _pid: u32) -> Result<bool> {
        Ok(false)
    }
}

#[test]
fn test_gx() {
    let mut gx = Gx::new("tests/gx".to_owned());
    let res = gx.run(1, 1).unwrap();
    let mut gx = Gx::new("tests/gx2".to_owned());
    let res = gx.run(1, 1).unwrap();
    let mut gx = Gx::new("tests/gx_normal".to_owned());
    let res = gx.run(1, 1).unwrap();
    let mut gx = Gx::new("tests/gx_ras".to_owned());
    let res = gx.run(1, 1).unwrap();
    let mut gx = Gx::new("tests/gx_nccl".to_owned());
    let res = gx.run(1, 1).unwrap();
    println!("{:#?}", res);
}
