use anyhow::{bail, Result};
use std::collections::HashMap;
use std::ffi::{CStr, CString};
use std::fs;
use std::path::Path;
use std::str::FromStr;

const INFINIBAND_CLASS_PATH: &str = "class/infiniband";

#[derive(Debug)]
pub struct InfiniBandCounters {
    pub legacy_port_multicast_rcv_packets: Option<u64>,
    pub legacy_port_multicast_xmit_packets: Option<u64>,
    pub legacy_port_rcv_data64: Option<u64>,
    pub legacy_port_rcv_packets64: Option<u64>,
    pub legacy_port_unicast_rcv_packets: Option<u64>,
    pub legacy_port_unicast_xmit_packets: Option<u64>,
    pub legacy_port_xmit_data64: Option<u64>,
    pub legacy_port_xmit_packets64: Option<u64>,
    pub excessive_buffer_overrun_errors: Option<u64>,
    pub link_downed: Option<u64>,
    pub link_error_recovery: Option<u64>,
    pub local_link_integrity_errors: Option<u64>,
    pub multicast_rcv_packets: Option<u64>,
    pub multicast_xmit_packets: Option<u64>,
    pub port_rcv_constraint_errors: Option<u64>,
    pub port_rcv_data: Option<u64>,
    pub port_rcv_discards: Option<u64>,
    pub port_rcv_errors: Option<u64>,
    pub port_rcv_packets: Option<u64>,
    pub port_rcv_remote_physical_errors: Option<u64>,
    pub port_rcv_switch_relay_errors: Option<u64>,
    pub port_xmit_constraint_errors: Option<u64>,
    pub port_xmit_data: Option<u64>,
    pub port_xmit_discards: Option<u64>,
    pub port_xmit_packets: Option<u64>,
    pub port_xmit_wait: Option<u64>,
    pub symbol_error: Option<u64>,
    pub unicast_rcv_packets: Option<u64>,
    pub unicast_xmit_packets: Option<u64>,
    pub vl15_dropped: Option<u64>,
}

#[derive(Debug)]
pub struct InfiniBandCountersIter<'a> {
    counters: &'a InfiniBandCounters,
    index: usize,
}

impl<'a> InfiniBandCountersIter<'a> {
    fn new(counters: &'a InfiniBandCounters) -> Self {
        InfiniBandCountersIter { counters, index: 0 }
    }
}

impl InfiniBandCounters {
    pub fn iter(&self) -> InfiniBandCountersIter<'_> {
        InfiniBandCountersIter::new(self)
    }
}

impl<'a> Iterator for InfiniBandCountersIter<'a> {
    type Item = (&'static str, Option<u64>);

    fn next(&mut self) -> Option<Self::Item> {
        let result = match self.index {
            0 => (
                "legacy_port_multicast_rcv_packets",
                self.counters.legacy_port_multicast_rcv_packets,
            ),
            1 => (
                "legacy_port_multicast_xmit_packets",
                self.counters.legacy_port_multicast_xmit_packets,
            ),
            2 => (
                "legacy_port_rcv_data64",
                self.counters.legacy_port_rcv_data64,
            ),
            3 => (
                "legacy_port_rcv_packets64",
                self.counters.legacy_port_rcv_packets64,
            ),
            4 => (
                "legacy_port_unicast_rcv_packets",
                self.counters.legacy_port_unicast_rcv_packets,
            ),
            5 => (
                "legacy_port_unicast_xmit_packets",
                self.counters.legacy_port_unicast_xmit_packets,
            ),
            6 => (
                "legacy_port_xmit_data64",
                self.counters.legacy_port_xmit_data64,
            ),
            7 => (
                "legacy_port_xmit_packets64",
                self.counters.legacy_port_xmit_packets64,
            ),
            8 => (
                "excessive_buffer_overrun_errors",
                self.counters.excessive_buffer_overrun_errors,
            ),
            9 => ("link_downed", self.counters.link_downed),
            10 => ("link_error_recovery", self.counters.link_error_recovery),
            11 => (
                "local_link_integrity_errors",
                self.counters.local_link_integrity_errors,
            ),
            12 => ("multicast_rcv_packets", self.counters.multicast_rcv_packets),
            13 => (
                "multicast_xmit_packets",
                self.counters.multicast_xmit_packets,
            ),
            14 => (
                "port_rcv_constraint_errors",
                self.counters.port_rcv_constraint_errors,
            ),
            15 => ("port_rcv_data", self.counters.port_rcv_data),
            16 => ("port_rcv_discards", self.counters.port_rcv_discards),
            17 => ("port_rcv_errors", self.counters.port_rcv_errors),
            18 => ("port_rcv_packets", self.counters.port_rcv_packets),
            19 => (
                "port_rcv_remote_physical_errors",
                self.counters.port_rcv_remote_physical_errors,
            ),
            20 => (
                "port_rcv_switch_relay_errors",
                self.counters.port_rcv_switch_relay_errors,
            ),
            21 => (
                "port_xmit_constraint_errors",
                self.counters.port_xmit_constraint_errors,
            ),
            22 => ("port_xmit_data", self.counters.port_xmit_data),
            23 => ("port_xmit_discards", self.counters.port_xmit_discards),
            24 => ("port_xmit_packets", self.counters.port_xmit_packets),
            25 => ("port_xmit_wait", self.counters.port_xmit_wait),
            26 => ("symbol_error", self.counters.symbol_error),
            27 => ("unicast_rcv_packets", self.counters.unicast_rcv_packets),
            28 => ("unicast_xmit_packets", self.counters.unicast_xmit_packets),
            29 => ("vl15_dropped", self.counters.vl15_dropped),
            _ => return None,
        };
        self.index += 1;
        Some(result)
    }
}

#[derive(Debug)]
pub struct InfiniBandHwCounters {
    pub duplicate_request: Option<u64>,
    pub implied_nak_seq_err: Option<u64>,
    pub lifespan: Option<u64>,
    pub local_ack_timeout_err: Option<u64>,
    pub np_cnp_sent: Option<u64>,
    pub np_ecn_marked_roce_packets: Option<u64>,
    pub out_of_buffer: Option<u64>,
    pub out_of_sequence: Option<u64>,
    pub packet_seq_err: Option<u64>,
    pub req_cqe_error: Option<u64>,
    pub req_cqe_flush_error: Option<u64>,
    pub req_remote_access_errors: Option<u64>,
    pub req_remote_invalid_request: Option<u64>,
    pub resp_cqe_error: Option<u64>,
    pub resp_cqe_flush_error: Option<u64>,
    pub resp_local_length_error: Option<u64>,
    pub resp_remote_access_errors: Option<u64>,
    pub rnr_nak_retry_err: Option<u64>,
    pub roce_adp_retrans: Option<u64>,
    pub roce_adp_retrans_to: Option<u64>,
    pub roce_slow_restart: Option<u64>,
    pub roce_slow_restart_cnps: Option<u64>,
    pub roce_slow_restart_trans: Option<u64>,
    pub rp_cnp_handled: Option<u64>,
    pub rp_cnp_ignored: Option<u64>,
    pub rx_atomic_requests: Option<u64>,
    pub rx_dct_connect: Option<u64>,
    pub rx_icrc_encapsulated: Option<u64>,
    pub rx_read_requests: Option<u64>,
    pub rx_write_requests: Option<u64>,
}

#[derive(Debug)]
pub struct InfiniBandHwCountersIter<'a> {
    counters: &'a InfiniBandHwCounters,
    index: usize,
}

impl<'a> InfiniBandHwCountersIter<'a> {
    fn new(counters: &'a InfiniBandHwCounters) -> Self {
        InfiniBandHwCountersIter { counters, index: 0 }
    }
}

impl<'a> Iterator for InfiniBandHwCountersIter<'a> {
    type Item = (&'static str, Option<u64>);

    fn next(&mut self) -> Option<Self::Item> {
        let result = match self.index {
            0 => ("duplicate_request", self.counters.duplicate_request),
            1 => ("implied_nak_seq_err", self.counters.implied_nak_seq_err),
            2 => ("lifespan", self.counters.lifespan),
            3 => ("local_ack_timeout_err", self.counters.local_ack_timeout_err),
            4 => ("np_cnp_sent", self.counters.np_cnp_sent),
            5 => (
                "np_ecn_marked_roce_packets",
                self.counters.np_ecn_marked_roce_packets,
            ),
            6 => ("out_of_buffer", self.counters.out_of_buffer),
            7 => ("out_of_sequence", self.counters.out_of_sequence),
            8 => ("packet_seq_err", self.counters.packet_seq_err),
            9 => ("req_cqe_error", self.counters.req_cqe_error),
            10 => ("req_cqe_flush_error", self.counters.req_cqe_flush_error),
            11 => (
                "req_remote_access_errors",
                self.counters.req_remote_access_errors,
            ),
            12 => (
                "req_remote_invalid_request",
                self.counters.req_remote_invalid_request,
            ),
            13 => ("resp_cqe_error", self.counters.resp_cqe_error),
            14 => ("resp_cqe_flush_error", self.counters.resp_cqe_flush_error),
            15 => (
                "resp_local_length_error",
                self.counters.resp_local_length_error,
            ),
            16 => (
                "resp_remote_access_errors",
                self.counters.resp_remote_access_errors,
            ),
            17 => ("rnr_nak_retry_err", self.counters.rnr_nak_retry_err),
            18 => ("roce_adp_retrans", self.counters.roce_adp_retrans),
            19 => ("roce_adp_retrans_to", self.counters.roce_adp_retrans_to),
            20 => ("roce_slow_restart", self.counters.roce_slow_restart),
            21 => (
                "roce_slow_restart_cnps",
                self.counters.roce_slow_restart_cnps,
            ),
            22 => (
                "roce_slow_restart_trans",
                self.counters.roce_slow_restart_trans,
            ),
            23 => ("rp_cnp_handled", self.counters.rp_cnp_handled),
            24 => ("rp_cnp_ignored", self.counters.rp_cnp_ignored),
            25 => ("rx_atomic_requests", self.counters.rx_atomic_requests),
            26 => ("rx_dct_connect", self.counters.rx_dct_connect),
            27 => ("rx_icrc_encapsulated", self.counters.rx_icrc_encapsulated),
            28 => ("rx_read_requests", self.counters.rx_read_requests),
            29 => ("rx_write_requests", self.counters.rx_write_requests),
            _ => return None,
        };
        self.index += 1;
        Some(result)
    }
}

impl<'a> IntoIterator for &'a InfiniBandHwCounters {
    type Item = (&'static str, Option<u64>);
    type IntoIter = InfiniBandHwCountersIter<'a>;

    fn into_iter(self) -> Self::IntoIter {
        InfiniBandHwCountersIter::new(self)
    }
}

#[derive(Debug)]
pub struct InfiniBandPort {
    pub name: String,
    pub port: u32,
    pub state: String,
    pub state_id: u32,
    pub phys_state: String,
    pub phys_state_id: u32,
    pub rate: u64,
    pub counters: InfiniBandCounters,
    pub hw_counters: InfiniBandHwCounters,
}
#[derive(Debug)]
pub struct InfiniBandDevice {
    pub name: String,
    pub board_id: Option<String>,
    pub firmware_version: Option<String>,
    pub hca_type: Option<String>,
    pub ports: HashMap<u32, InfiniBandPort>,
}
#[derive(Debug)]
pub struct InfiniBandClass {
    pub devices: HashMap<String, InfiniBandDevice>,
}

impl InfiniBandClass {
    pub fn new(sys_path: &str) -> Result<Self> {
        let path = Path::new(sys_path).join(INFINIBAND_CLASS_PATH);
        let dirs = fs::read_dir(path)?;
        let mut devices = HashMap::new();

        for entry in dirs {
            let entry = entry?;
            let name = entry.file_name();
            let name = name.to_string_lossy().into_owned();
            let device = parse_infiniband_device(sys_path, &name)?;
            devices.insert(name, device);
        }

        Ok(InfiniBandClass { devices })
    }

    pub fn to_traffic_stat_hashmap(&self) -> HashMap<String, (u64, u64)> {
        let mut stats = HashMap::new();
        for (name, device) in &self.devices {
            for (port, port_info) in &device.ports {
                let key = format!("{name}-{port}");
                let xmit = port_info.counters.port_xmit_data.unwrap();
                let recv = port_info.counters.port_rcv_data.unwrap();
                stats.insert(key, (xmit, recv));
            }
        }
        stats
    }
}

fn parse_infiniband_device(sys_path: &str, name: &str) -> Result<InfiniBandDevice> {
    let path = Path::new(sys_path).join(INFINIBAND_CLASS_PATH).join(name);
    let mut device = InfiniBandDevice {
        name: name.to_string(),
        board_id: None,
        firmware_version: None,
        hca_type: None,
        ports: HashMap::new(),
    };

    let fw_ver = fs::read_to_string(path.join("fw_ver"))?;
    device.firmware_version = Some(fw_ver.trim().to_string());

    for file in ["board_id", "hca_type"] {
        let file_path = path.join(file);
        if file_path.exists() {
            let content = fs::read_to_string(&file_path)?;
            match file {
                "board_id" => device.board_id = Some(content.trim().to_string()),
                "hca_type" => device.hca_type = Some(content.trim().to_string()),
                _ => {}
            }
        }
    }

    let ports_path = path.join("ports");
    let ports = fs::read_dir(ports_path)?;
    for entry in ports {
        let entry = entry?;
        let port_name = entry.file_name();
        let port_name = port_name.to_string_lossy().into_owned();
        let port = parse_infiniband_port(sys_path, name, &port_name)?;
        device.ports.insert(port.port, port);
    }

    Ok(device)
}

fn parse_infiniband_port(sys_path: &str, name: &str, port: &str) -> Result<InfiniBandPort> {
    let port_number = u32::from_str(port)?;
    let port_path = Path::new(sys_path)
        .join(INFINIBAND_CLASS_PATH)
        .join(name)
        .join("ports")
        .join(port);

    let state = fs::read_to_string(port_path.join("state"))?;
    let (state_id, state) = parse_state(&state)?;

    let phys_state = fs::read_to_string(port_path.join("phys_state"))?;
    let (phys_state_id, phys_state) = parse_state(&phys_state)?;

    let rate = fs::read_to_string(port_path.join("rate"))?;
    let rate = parse_rate(&rate)?;

    let counters = parse_infiniband_counters(&port_path)?;
    let hw_counters = parse_infiniband_hw_counters(&port_path)?;

    Ok(InfiniBandPort {
        name: name.to_string(),
        port: port_number,
        state,
        state_id,
        phys_state,
        phys_state_id,
        rate,
        counters,
        hw_counters,
    })
}

fn parse_state(s: &str) -> Result<(u32, String)> {
    let parts: Vec<&str> = s.splitn(2, ':').collect();
    if parts.len() != 2 {
        bail!("Failed to split {} into 'ID: NAME'", s)
    }
    let name = parts[1].trim().to_string();
    let id = u32::from_str(parts[0].trim())?;
    Ok((id, name))
}

fn parse_rate(s: &str) -> Result<u64> {
    let parts: Vec<&str> = s.split_whitespace().collect();
    if parts.len() < 2 {
        bail!("Failed to split {}", s)
    }
    let value = f64::from_str(parts[0])?;
    let rate = (value * 125_000_000.0) as u64;
    Ok(rate)
}

fn parse_infiniband_counters(port_path: &Path) -> Result<InfiniBandCounters> {
    let mut counters = InfiniBandCounters {
        legacy_port_multicast_rcv_packets: None,
        legacy_port_multicast_xmit_packets: None,
        legacy_port_rcv_data64: None,
        legacy_port_rcv_packets64: None,
        legacy_port_unicast_rcv_packets: None,
        legacy_port_unicast_xmit_packets: None,
        legacy_port_xmit_data64: None,
        legacy_port_xmit_packets64: None,

        excessive_buffer_overrun_errors: None,
        link_downed: None,
        link_error_recovery: None,
        local_link_integrity_errors: None,
        multicast_rcv_packets: None,
        multicast_xmit_packets: None,
        port_rcv_constraint_errors: None,
        port_rcv_data: None,
        port_rcv_discards: None,
        port_rcv_errors: None,
        port_rcv_packets: None,
        port_rcv_remote_physical_errors: None,
        port_rcv_switch_relay_errors: None,
        port_xmit_constraint_errors: None,
        port_xmit_data: None,
        port_xmit_discards: None,
        port_xmit_packets: None,
        port_xmit_wait: None,
        symbol_error: None,
        unicast_rcv_packets: None,
        unicast_xmit_packets: None,
        vl15_dropped: None,
    };

    let counters_path = port_path.join("counters");
    if counters_path.exists() {
        for entry in fs::read_dir(counters_path)? {
            let entry = entry?;
            let file_name = entry.file_name();
            let file_name = file_name.to_string_lossy().into_owned();
            let value = fs::read_to_string(entry.path())?;
            let value = u64::from_str(value.trim()).ok();

            match file_name.as_str() {
                "excessive_buffer_overrun_errors" => {
                    counters.excessive_buffer_overrun_errors = value
                }
                "link_downed" => counters.link_downed = value,
                "link_error_recovery" => counters.link_error_recovery = value,
                "local_link_integrity_errors" => counters.local_link_integrity_errors = value,
                "multicast_rcv_packets" => counters.multicast_rcv_packets = value,
                "multicast_xmit_packets" => counters.multicast_xmit_packets = value,
                "port_rcv_constraint_errors" => counters.port_rcv_constraint_errors = value,
                "port_rcv_data" => counters.port_rcv_data = value.map(|v| v * 4),
                "port_rcv_discards" => counters.port_rcv_discards = value,
                "port_rcv_errors" => counters.port_rcv_errors = value,
                "port_rcv_packets" => counters.port_rcv_packets = value,
                "port_rcv_remote_physical_errors" => {
                    counters.port_rcv_remote_physical_errors = value
                }
                "port_rcv_switch_relay_errors" => counters.port_rcv_switch_relay_errors = value,
                "port_xmit_constraint_errors" => counters.port_xmit_constraint_errors = value,
                "port_xmit_data" => counters.port_xmit_data = value.map(|v| v * 4),
                "port_xmit_discards" => counters.port_xmit_discards = value,
                "port_xmit_packets" => counters.port_xmit_packets = value,
                "port_xmit_wait" => counters.port_xmit_wait = value,
                "symbol_error" => counters.symbol_error = value,
                "unicast_rcv_packets" => counters.unicast_rcv_packets = value,
                "unicast_xmit_packets" => counters.unicast_xmit_packets = value,
                "VL15_dropped" => counters.vl15_dropped = value,
                _ => {}
            }
        }
    }

    Ok(counters)
}

fn parse_infiniband_hw_counters(port_path: &Path) -> Result<InfiniBandHwCounters> {
    let mut hw_counters = InfiniBandHwCounters {
        duplicate_request: None,
        implied_nak_seq_err: None,
        lifespan: None,
        local_ack_timeout_err: None,
        np_cnp_sent: None,
        np_ecn_marked_roce_packets: None,
        out_of_buffer: None,
        out_of_sequence: None,
        packet_seq_err: None,
        req_cqe_error: None,
        req_cqe_flush_error: None,
        req_remote_access_errors: None,
        req_remote_invalid_request: None,
        resp_cqe_error: None,
        resp_cqe_flush_error: None,
        resp_local_length_error: None,
        resp_remote_access_errors: None,
        rnr_nak_retry_err: None,
        roce_adp_retrans: None,
        roce_adp_retrans_to: None,
        roce_slow_restart: None,
        roce_slow_restart_cnps: None,
        roce_slow_restart_trans: None,
        rp_cnp_handled: None,
        rp_cnp_ignored: None,
        rx_atomic_requests: None,
        rx_dct_connect: None,
        rx_icrc_encapsulated: None,
        rx_read_requests: None,
        rx_write_requests: None,
    };

    let hw_counters_path = port_path.join("hw_counters");
    if hw_counters_path.exists() {
        for entry in fs::read_dir(hw_counters_path)? {
            let entry = entry?;
            let file_name = entry.file_name();
            let file_name = file_name.to_string_lossy().into_owned();
            let value = fs::read_to_string(entry.path())?;
            let value = u64::from_str(value.trim()).ok();

            match file_name.as_str() {
                "duplicate_request" => hw_counters.duplicate_request = value,
                "implied_nak_seq_err" => hw_counters.implied_nak_seq_err = value,
                "lifespan" => hw_counters.lifespan = value,
                "local_ack_timeout_err" => hw_counters.local_ack_timeout_err = value,
                "np_cnp_sent" => hw_counters.np_cnp_sent = value,
                "np_ecn_marked_roce_packets" => hw_counters.np_ecn_marked_roce_packets = value,
                "out_of_buffer" => hw_counters.out_of_buffer = value,
                "out_of_sequence" => hw_counters.out_of_sequence = value,
                "packet_seq_err" => hw_counters.packet_seq_err = value,
                "req_cqe_error" => hw_counters.req_cqe_error = value,
                "req_cqe_flush_error" => hw_counters.req_cqe_flush_error = value,
                "req_remote_access_errors" => hw_counters.req_remote_access_errors = value,
                "req_remote_invalid_request" => hw_counters.req_remote_invalid_request = value,
                "resp_cqe_error" => hw_counters.resp_cqe_error = value,
                "resp_cqe_flush_error" => hw_counters.resp_cqe_flush_error = value,
                "resp_local_length_error" => hw_counters.resp_local_length_error = value,
                "resp_remote_access_errors" => hw_counters.resp_remote_access_errors = value,
                "rnr_nak_retry_err" => hw_counters.rnr_nak_retry_err = value,
                "roce_adp_retrans" => hw_counters.roce_adp_retrans = value,
                "roce_adp_retrans_to" => hw_counters.roce_adp_retrans_to = value,
                "roce_slow_restart" => hw_counters.roce_slow_restart = value,
                "roce_slow_restart_cnps" => hw_counters.roce_slow_restart_cnps = value,
                "roce_slow_restart_trans" => hw_counters.roce_slow_restart_trans = value,
                "rp_cnp_handled" => hw_counters.rp_cnp_handled = value,
                "rp_cnp_ignored" => hw_counters.rp_cnp_ignored = value,
                "rx_atomic_requests" => hw_counters.rx_atomic_requests = value,
                "rx_dct_connect" => hw_counters.rx_dct_connect = value,
                "rx_icrc_encapsulated" => hw_counters.rx_icrc_encapsulated = value,
                "rx_read_requests" => hw_counters.rx_read_requests = value,
                "rx_write_requests" => hw_counters.rx_write_requests = value,
                _ => {}
            }
        }
    }

    Ok(hw_counters)
}

fn send_metric(
    key: String,
    value: u64,
    cb: unsafe extern "C" fn(*const libc::c_char, u64),
) -> Result<()> {
    let c_key = CString::new(key)?;
    unsafe { cb(c_key.as_ptr(), value) };
    Ok(())
}

fn extract_number(s: &str) -> Option<u32> {
    s.split('_')
        .last()
        .and_then(|num_str| num_str.parse::<u32>().ok())
}

fn infiniband_metrics_read_internal(
    cb: unsafe extern "C" fn(*const libc::c_char, u64),
    sys_path: &str,
) -> Result<()> {
    let ib = InfiniBandClass::new(sys_path)?;

    for (name, device) in ib.devices {
        let gpu = if name.contains("bond") {
            extract_number(name.as_str())
        } else {
            None
        };
        let board_id = device.board_id.map_or("None".to_owned(), |x| x.clone());
        let firmware_version = device
            .firmware_version
            .map_or("None".to_owned(), |x| x.clone());
        for (_, port) in device.ports {
            let key = match gpu {
                Some(gpu) => {
                    format!(
                        "name {name} gpu {gpu} board_id {} firmware_version {} port {} rate {}",
                        board_id, firmware_version, port.port, port.rate
                    )
                }
                None => {
                    format!(
                        "name {name} board_id {} firmware_version {} port {} rate {}",
                        board_id, firmware_version, port.port, port.rate
                    )
                }
            };

            for (metric_name, metric_value) in port.counters.iter() {
                if let Some(metric_value) = metric_value {
                    let metric_key =
                        format!("INFINIBAND_COUNTER_{} {key}", metric_name.to_uppercase());
                    let _ = send_metric(metric_key, metric_value, cb);
                }
            }

            for (metric_name, metric_value) in port.hw_counters.into_iter() {
                if let Some(metric_value) = metric_value {
                    let metric_key =
                        format!("INFINIBAND_HW_COUNTER_{} {key}", metric_name.to_uppercase());
                    let _ = send_metric(metric_key, metric_value, cb);
                }
            }
        }
    }
    Ok(())
}

#[no_mangle]
pub fn infiniband_metrics_read(cb: unsafe extern "C" fn(*const libc::c_char, u64)) {
    let _ = infiniband_metrics_read_internal(cb, "/sys");
}

#[no_mangle]
unsafe extern "C" fn test_infiniband_metrics_read_printer(key: *const libc::c_char, value: u64) {
    let key = CStr::from_ptr(key);
    println!("{:?}: {value}", key);
}

pub fn test_infiniband_metrics_read() {
    let _ = infiniband_metrics_read_internal(test_infiniband_metrics_read_printer, "./tests");
}

#[test]
fn test_infiniband() {
    test_infiniband_metrics_read();
}
