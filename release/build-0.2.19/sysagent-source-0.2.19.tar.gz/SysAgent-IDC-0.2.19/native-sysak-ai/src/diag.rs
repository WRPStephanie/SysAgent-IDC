use std::path::Path;

use crate::{
    errors,
    gpu::Gpu,
    gpu_process::GpuProcess,
    gx::Gx,
    nvml::{DeviceWrapper, NvmlInfo, NvmlWrapper},
};
use anyhow::{bail, Result};
use chrono::Local;
use serde::Serialize;
#[derive(Clone, Debug, Serialize)]
pub struct Diag {
    base: NvmlInfo,
}

impl Diag {
    pub fn diag(gx: &str, t_s: u64) -> Result<()> {
        match NvmlInfo::new() {
            Ok(nvml) => {
                Diag::__diag(gx, nvml, t_s)?;
            }
            Err(e) => {
                log::debug!("failed to get hardware info: {e}");
                Diag::__diag_without_nvml(gx, t_s)?;
            }
        };
        Ok(())
    }

    pub fn __diag_without_nvml(gx: &str, t_s: u64) -> Result<()> {
        let nvml = NvmlInfo::default();
        Diag::__diag(gx, nvml, t_s)
    }

    pub fn __diag(gx: &str, mut nvml: NvmlInfo, t_s: u64) -> Result<()> {
        let path = Path::new(gx);
        if !path.exists() {
            bail!("GX command not found")
        }
        let time = Local::now().format("%Y-%m-%d %H:%M:%S").to_string();
        let gx = Gx::new(gx.to_string());
        let mut checked_ras = false;
        std::thread::sleep(std::time::Duration::from_secs(1));
        for (_, process) in nvml.processes.iter_mut() {
            let _ = process.update_cpu_percent();
        }

        let pids = nvml.processes.keys().cloned().collect::<Vec<_>>();
        let mut gx_run_times = 0;
        for pid in pids {
            if !nvml.processes.get(&pid).unwrap().gpus.is_empty()
                && nvml.processes.get(&pid).unwrap().gpus[0].sm_util == 0
            {
                continue;
            }
            gx_run_times += 1;
            if let Ok(res) = gx.run(pid, t_s) {
                log::debug!("gx result: {:?}", res);
                if !checked_ras {
                    for (bus_id, errors) in &res.ras.errors {
                        nvml.add_gpu_errors(bus_id, errors);
                        checked_ras = true;
                    }
                }

                if !res.nccl.problems.is_empty() {
                    let (info, info_en) = if res.nccl.verboses.is_empty() {
                        ("NCCL hang".to_owned(), "NCCL hang".to_owned())
                    } else {
                        (
                            format!("NCCL hang: {}", res.nccl.verboses[0]),
                            format!("NCCL hang: {}", res.nccl.verboses[0]),
                        )
                    };
                    let error = errors::Errors::new(
                        time.clone(), info, "N/A".to_owned(),
                        info_en, "N/A".to_owned(),
                    );
                    nvml.set_nccl_hang(pid, time.clone(), error);
                }

                for (verbose, _problem) in res.hang.verboses.iter().zip(res.hang.problems.iter()) {
                    let error = errors::Errors::new(
                        time.clone(),
                        format!("Gpu算子hang: {}", verbose),
                        "建议检查下该核函数代码逻辑".to_owned(),
                        format!("GPU kernel hang: {}", verbose),
                        "Check the kernel function code logic".to_owned(),
                    );
                    nvml.add_proc_error(time.clone(), pid, error);
                }
            }
        }

        let pid = std::process::id();
        if let Ok(true) = gx.detect_driver_hang(pid) {
            nvml.set_driver_hang();
        }

        if nvml.processes.is_empty() || gx_run_times == 0 {
            if let Ok(res) = gx.run(pid, t_s) {
                if !checked_ras {
                    for (bus_id, errors) in &res.ras.errors {
                        nvml.add_gpu_errors(bus_id, errors);
                    }
                }
            }
        }

        // 运行硬件健康检测（gpudiag），结果追加到 nvml.errors / errors_en
        if let Err(e) = crate::gpudiag::check_all(&mut nvml) {
            log::debug!("gpudiag check_all failed: {}", e);
        }

        nvml.build_summary();

        if nvml.errors.is_empty() && nvml.gpus.is_empty() {
            nvml.sysom_code = 1;
            nvml.sysom_err_msg = "不支持非GPU实例或者未安装GPU驱动".to_string();
            nvml.sysom_err_msg_en = "Non-GPU instance not supported or GPU driver not installed".to_string();
        }

        let diag = Diag { base: nvml };

        println!("{}", serde_json::to_string(&diag.base)?);
        Ok(())
    }
}

#[test]
fn test_diag() {
    let _ = Diag::diag("tests/gx", 1);
    let mut nvml = NvmlInfo::new().unwrap();

    nvml.processes.insert(1, GpuProcess::new(1).unwrap());
    nvml.processes.insert(2, GpuProcess::new(1).unwrap());

    let mut dev = DeviceWrapper::new();
    dev.bus_id = "0000:00:07".to_owned();
    let gpu = Gpu::from(&dev);

    nvml.gpus.push(gpu);

    Diag::__diag("tests/gx", nvml.clone(), 1);
    Diag::__diag("tests/gx2", nvml.clone(), 1);
    Diag::__diag("tests/gx_nccl", nvml.clone(), 1);
    Diag::__diag("tests/gx_ras", nvml.clone(), 1);
    Diag::__diag("tests/gx_hang", nvml.clone(), 1);

    nvml.processes.clear();

    Diag::__diag("tests/gx", nvml.clone(), 1);
    Diag::__diag("tests/gx2", nvml.clone(), 1);
    Diag::__diag("tests/gx_nccl", nvml.clone(), 1);
    Diag::__diag("tests/gx_ras", nvml.clone(), 1);
    Diag::__diag("tests/gx_hang", nvml.clone(), 1);
    Diag::__diag("tests/gx_not_found", nvml.clone(), 1);
}
