use chrono::Local;
use diag::Diag;
use std::fs::OpenOptions;
use std::io::Write;
use std::time::Duration;
pub mod diag;
pub mod errors;
pub mod gpu;
pub mod gpu_process;
pub mod gpudiag;
pub mod gx;
pub mod nvml;
pub mod rocm_smi;
use fundu::CustomDurationParser;
use fundu::CustomTimeUnit;
use fundu::SaturatingInto;
use fundu::TimeUnit;
use fundu::TimeUnit::*;
use structopt::StructOpt;

fn parse_humantime(time: &str, unit: TimeUnit) -> Duration {
    let mut parser = CustomDurationParser::with_time_units(&[
        CustomTimeUnit::with_default(Second, &["s", "secs"]),
        CustomTimeUnit::with_default(MilliSecond, &["ms"]),
        CustomTimeUnit::with_default(MicroSecond, &["us"]),
    ]);
    parser
        .default_unit(unit)
        .parse(time)
        .unwrap()
        .saturating_into()
}

fn parse_humantime_with_second_default(time: &str) -> Duration {
    parse_humantime(time, Second)
}

#[derive(Debug, StructOpt)]
#[structopt(name = "rtrace", about = "Diagnosing tools of kernel network")]
pub struct Command {
    #[structopt(short, long, default_value = "1s", parse(from_str = parse_humantime_with_second_default), help = "Network jitter threshold")]
    threshold: Duration,
}

fn main() {
    env_logger::init();
    let opt = Command::from_args();
    let ns = opt.threshold.as_secs();
    match Diag::diag("/usr/bin/gx", ns) {
        Ok(_) => {}
        Err(e) => {
            // /var/log/sysak/ai_diag.log
            let mut file = OpenOptions::new()
                .create(true)
                .append(true)
                .open("/var/log/sysak/ai_diag_error.log")
                .unwrap();

            let _ = writeln!(
                file,
                "{}: failed to diag: {}",
                Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),
                e
            );
            log::error!("failed to diag: {e}");
        }
    }
}

#[test]
fn test_main() {
    // main();
}
