use crate::errors::Errors;
use crate::nvml::DeviceWrapper;
use nvml_wrapper::enum_wrappers::device::PerformanceState;
use nvml_wrapper::struct_wrappers::device::MemoryInfo;
use serde::Deserialize;
use serde::Serialize;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Gpu {
    fan: u32,
    temp: u32,
    perf: PerformanceState,
    power: u32,
    util: u32,
    mem: MemoryInfo,
    pub normal: bool,
    #[serde(skip)]
    pub bus_id: String,
    pub erros: Vec<Errors>,
}

impl From<&DeviceWrapper> for Gpu {
    fn from(dev: &DeviceWrapper) -> Self {
        Gpu {
            fan: dev.fan,
            temp: dev.temp,
            perf: dev.perf.clone(),
            power: dev.power,
            util: dev.util,
            mem: dev.mem.clone(),
            normal: true,
            bus_id: dev.bus_id.clone().to_uppercase(),
            erros: vec![],
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::nvml::DeviceWrapper;

    #[test]
    fn test_gpu() {
        let dev = DeviceWrapper::new();
        Gpu::from(&dev);
    }
}
