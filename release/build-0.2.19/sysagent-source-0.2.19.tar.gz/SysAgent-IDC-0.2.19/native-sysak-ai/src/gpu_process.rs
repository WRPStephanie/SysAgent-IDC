use crate::errors::Errors;
use anyhow::Result;
use psutil::process::Process;
use serde::Deserialize;
use serde::Serialize;

#[derive(Clone, Debug, Serialize)]
pub struct GpuProcess {
    pub pid: u32,
    pub cpu_util: f32,
    pub mem: u64,
    pub cmd: String,
    pub gpus: Vec<GpuProcessGpuInfo>,
    pub normal: bool,
    #[serde(skip)]
    proc: Process,
    pub erros: Vec<Errors>,
}

impl GpuProcess {
    pub fn new(pid: u32) -> Result<Self> {
        let mut proc = Process::new(pid)?;
        proc.cpu_percent()?;
        let mut cmdline = proc.cmdline()?.unwrap_or("-".to_string());
        cmdline.truncate(128);
        Ok(GpuProcess {
            pid,
            cpu_util: 0.0,
            normal: true,
            mem: proc.memory_info()?.rss(),
            cmd: cmdline,
            gpus: vec![],
            proc,
            erros: vec![],
        })
    }

    pub fn update_cpu_percent(&mut self) -> Result<()> {
        let cpu = self.proc.cpu_percent()?;
        self.cpu_util = cpu;
        Ok(())
    }
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct GpuProcessGpuInfo {
    pub id: u32,
    pub mem_util: u32,
    pub sm_util: u32,
}

#[test]
fn test_gpu_process() {
    let mut proc = GpuProcess::new(1).unwrap();
    proc.update_cpu_percent().unwrap();
}
